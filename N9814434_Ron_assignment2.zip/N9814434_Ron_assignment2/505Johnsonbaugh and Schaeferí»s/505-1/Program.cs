﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace _505_1
{
    class Program
    {
        static int[][] Median = new int[20][];// 20 arraies for finding different length arraies' medians
        static double[] time = new double[20];// store each arraies' running time
        static int repeatTime = 5;// repeat time
        static Stopwatch watch = new Stopwatch();// record time
        static int mid;// store median number
        static double []counter = new double[20];// counter basic operation
        static int pivotloc;//pivot location
        //there are 20 arraies and set each arraies' length from 2001 to 21001， step 1000;
        static void SetArry()
        {
            for (int i = 0; i < Median.Length; i++)
            {
                Median[i] = new int[(i + 1) * 1000 + 1001];
            }

        }
        static void Main(string[] args)
        {
            SetArry();//initialise each arrie's elements
            Console.WriteLine("Repeat {0} times and use average time to imporve accuracy", repeatTime);
            for (int i = 0; i < repeatTime; i++)// repeat 5 times
            {
                GetArray();
                for (int row = 0; row < Median.Length; row++)
                {
                    watch.Start();//time record start
                    if (Median[row].Length == 1)// if the length of array is 1, median number is first number
                    {
                        mid = Median[row][0];
                    }
                    else//if length of array larger than 1, goes to partition and select algorithm
                    {
                        mid = Partition(Median, 0, Median[row].Length, row);
                        Console.WriteLine("mid of Median[{0}] is {1}", Median[row].Length, mid);
                    }
                    watch.Stop();//time record stop
                    time[row] += double.Parse(watch.ElapsedMilliseconds.ToString());//record time of each array
                    //Console.WriteLine("{0} row's time is {1}",row, time[row]);
                    watch.Reset();//each time reset record time, start from zero
                }
            }
            Counter(Median.Length, repeatTime);
            AverageTime(repeatTime);//calculate average running time of each array, improving accuracy
            Console.ReadLine();

        }
            // assign elements in each array by random, which means all the numbers in each array are random;
            //row is from 0 to 19, for 20 arrays(f2001 to 21001， step 1000), element is index of each element in each array, its value is random from 1 to its array’s length
        static void GetArray()
        {
            Random rd = new Random();
            for (int row = 0; row < Median.Length; row++)//Median.Length = 20
            {
                for (int element = 0; element < Median[row].Length; element++)//assign random number for each array's elements
                {
                    Median[row][element] = rd.Next(1, Median[row].Length);
                    //Console.Write("{0}\t", Median[row][element]);// this line can show all the elements of each array
                }
            }
        }
        static int Partition(int[][] A, int l, int h, int row)//A is array which is applied this algorithm, l is the first element's index, h is the last element's index, row is the number of array
        {
            int temporary, pivotval;//temporary used for swap tow numbers, pivotval is store first element's value in one array
                pivotloc = l;
                pivotval = A[row][l];
                //Console.Write("\npivot value is {0}", pivotval);
                for (int j = l + 1; j < h; j++)// From subarray's(or searching array) first element to last element for comparsion.
                {
                    if (A[row][j] < pivotval)// when the afterwards element's value is smaller than pivota value, swap the two values and pivot location adds one, counter basic operation adds one, too
                    {
                        pivotloc += 1;
                        temporary = A[row][j];
                        A[row][j] = A[row][pivotloc];
                        A[row][pivotloc] = temporary;
                        counter[row]++;
                    }
                }
                // After the loop, swap first element's value(after loop) in the searching array and original first value(before loop) in the array. Basic operation counter adds one
                temporary = A[row][l];
                A[row][l] = A[row][pivotloc];
                A[row][pivotloc] = temporary;
                counter[row]++;
            Select(A,row,l,h,pivotloc);// when the partition algorithm is finished, then goes to select algorithm
            //Console.WriteLine("{0} row's Median value is {1}", row, Median[row][pivotloc]);//this line can show each array's median
            return mid;
        }
        static void Select(int[][] A, int row, int l, int h, int pivotloc)//A is array which is applied this algorithm, l is the first element's index, h is the last element's index, row is the number of array
        {
            if (pivotloc == A[row].Length / 2)//if pivot location is at mid of the array, we find the median
            {
                mid = A[row][pivotloc];// assign the pivot value to  mid
            }
            else if (pivotloc < A[row].Length / 2)// if pivot location is smaller than mid, which means median must be at right side of pivot
            {
                l = pivotloc + 1;// cut the array to subarry, which starts from next to pivot location to last of the array
                Partition(A,l,h,row);// goes to partition algorithm
            }
            else if (pivotloc > A[row].Length / 2)// if pivot location is larger than mid, which means median must be at left side of pivot
            {
                h = pivotloc;// cut the array to subarry, which starts from zero to (pivot location - 1)
                Partition(A, l, h, row);// goes to partition algorithm
            }
        }
        // This method is used to counter basic opertaion for 20 arrays respectively
        static void Counter(int row, int repeat)// row represent which one of 20 arrays. because the algorithm runs repeat(which is 1000) times.Hence, the counter is the whole number of 1000 times basic operation, the counter should be divided by repert times (1000)
        {
            for (int i = 0; i < row; i++)
            {
                Console.WriteLine("Array {0}'s basic operation counter is {1}", i + 1 , counter[i]/repeat);
            }
        }
        static void AverageTime(int repeat)// caculate average time ,the experiment runs 5 times and record 5 times' running time and divided by 5
        {
            for (int row = 0; row < Median.Length; row++)
            {
                time[row] /= repeat;// each array time divided by 5
                Console.WriteLine("Averge time of {0} size is {1}ms", Median[row].Length, time[row]);
            }
        }
    }
}
