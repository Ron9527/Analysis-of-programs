﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace _505
{
    class Program
    {
        static int[][] Median = new int[20][];// 20 arraies for finding different length arraies' medians
        static double[] time = new double[20];// store each arraies' running time
        static int repeatTime = 5;// repeat time
        static double[] counter = new double[20];// basic operation counter
        static Stopwatch watch = new Stopwatch();// record time
        //there are 20 arraies and set each arraies' length from 2001 to 21001， step 1000;
        static void SetArry()
        {
            for (int i = 0; i < Median.Length; i++)
            {
                Median[i] = new int[(i + 1) * 1000 + 1001];
            }
        }
        static void Main(string[] args)
        {
            SetArry();//initialise each arrie's elements
            Console.WriteLine("Repeat {0} times and use average time to imporve accuracy", repeatTime);
            for (int i = 0; i < repeatTime; i++)// repeat 5 times
            {
                GetArray();
                Algorithm();
            }
            Counter(Median.Length, repeatTime);
            AverageTime(repeatTime);
            Console.ReadLine();
        }
        // assign elements in each array by random, which means all the numbers in each array are random;
        //row is from 0 to 19, for 20 arrays(f2001 to 21001， step 1000), element is index of each element in each array, its value is random from 1 to its array’s length
        static void GetArray()
        {
            Random rd = new Random();
            for (int row = 0; row < Median.Length; row++)//Median.Length = 20
            {
                for (int element = 0; element < Median[row].Length; element++)//assign random number for each array's elements
                {
                    Median[row][element] = rd.Next(1, Median[row].Length);
                    //Console.Write("{0}\t", Median[row][element]);// this line can show all the elements of each array
                }
            }
        }
        // algorithm for finding the median
        static void Algorithm()
        {
            int mid = 0, k;// mid for assign median, k is middle position of each array
            for (int row = 0; row < Median.Length; row++)// row is from 0 to 19, 20 arraies
            {
                watch.Start();//time record start
                if (Median[row].Length % 2 == 0)// k's value depends on median's lengh equal to odd or even
                {
                    k = Median[row].Length / 2;
                }
                else
                {
                    k = Median[row].Length / 2 + 1;
                }
                for (int i = 0; i < Median[row].Length; i++)// i is from 0 to length of each array, such as 2000,3000....
                {
                    int numSmaller = 0, numEqual = 0;// numSmall store number of smaller than median and numEqual store number of equal to median
                    for (int j = 0; j < Median[row].Length; j++)// j is from 0 to length of each array, such as 1000,2000,3000....
                    {
                        if (Median[row][j] < Median[row][i])// comparsion and find small number
                        {
                            numSmaller += 1;//if there was a small number, numSmall + 1;
                            counter[row]++;// basic operation counter adds 1
                        }
                        else if (Median[row][j] == Median[row][i])// comparsion and find equal number
                        {
                            numEqual += 1;//if there was a equal number, numEqual + 1;
                            counter[row]++;// basic operation counter adds 1
                        }
                    }
                    if (numSmaller < k && k < (numSmaller + numEqual + 1))// condition for judge median
                    {
                        mid = Median[row][i];
                    }
                }
                watch.Stop();//time record end
                Console.WriteLine("mid of Median[{0}] is {1}", Median[row].Length, mid);
                time[row] += double.Parse(watch.ElapsedMilliseconds.ToString());// time records in millisecond
                watch.Reset();// for each array's loop, time record needs to reset;
            }
        }
        // This method is used to counter basic opertaion for 20 arrays respectively
        static void Counter(int row, int repeat)
        {
            for (int i = 0; i < row; i++)
            {
                Console.WriteLine("Array {0}'s basic operation counter is {1}", i + 1, counter[i] / repeat);
            }
        }
        static void AverageTime(int repeat)// caculate average time ,the experiment runs 5 times and record 5 times' running time and divided by 5
        {
            for (int row = 0; row < Median.Length; row++)
            {
                time[row] /= repeat;// each array time divided by 5
                Console.WriteLine("Averge time of {0} size is {1}ms", Median[row].Length , time[row]); 
            }
        }
    }
}
